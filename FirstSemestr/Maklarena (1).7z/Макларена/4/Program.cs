﻿using System;

namespace _4
{
    class Program //Леонтьев Илья Андреевич 11-012      4 задача
    {
        static void Main(string[] args)
        {
            double tochnost = Math.Pow(10, -9);
            Console.WriteLine("Введите значение: ");
            double input = double.Parse(Console.ReadLine());
            Console.WriteLine(Funk4(input, tochnost));
        }

        static public int Fact(int number)
        {
            int result = 1;
            for (int i = number; i > 1; i--)
            {
                result = result * i;
            }
            return result;
        }

        static double Funk4(double userI, double tochnost)
        {
            double total = 1;
            int N = 0;

            while (true)
            {
                if (total < tochnost)
                {
                    break;
                }
                total += Math.Pow(userI, 2 * N) / Fact(2 * N);

                N++;
            }
            return total;
        }
    }
}
